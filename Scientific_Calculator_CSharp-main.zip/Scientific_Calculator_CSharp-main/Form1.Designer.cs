﻿namespace Cientific_Calculator
{
    partial class Scientific_Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Principal = new System.Windows.Forms.TextBox();
            this.MC_Button = new System.Windows.Forms.Button();
            this.MR_Button = new System.Windows.Forms.Button();
            this.MS_Button = new System.Windows.Forms.Button();
            this.MPlus_Button = new System.Windows.Forms.Button();
            this.MSust_Button = new System.Windows.Forms.Button();
            this.CE_Button = new System.Windows.Forms.Button();
            this.C_Button = new System.Windows.Forms.Button();
            this.sinh_Button = new System.Windows.Forms.Button();
            this.cosh_Button = new System.Windows.Forms.Button();
            this.tanh_Button = new System.Windows.Forms.Button();
            this.Exp_Button = new System.Windows.Forms.Button();
            this.Factorial_Button = new System.Windows.Forms.Button();
            this.Euler_Button = new System.Windows.Forms.Button();
            this.Tentox_Button = new System.Windows.Forms.Button();
            this.Percentage_Button = new System.Windows.Forms.Button();
            this.NegPos_Button = new System.Windows.Forms.Button();
       //     this.sec_Button = new System.Windows.Forms.Button();
            this.csc_Button = new System.Windows.Forms.Button();
            this.cot_Button = new System.Windows.Forms.Button();
            this.log_Button = new System.Windows.Forms.Button();
            this.NatLog_Button = new System.Windows.Forms.Button();
            this.tan_Button = new System.Windows.Forms.Button();
            this.cos_Button = new System.Windows.Forms.Button();
            this.sin_Button = new System.Windows.Forms.Button();
            this.xRaisedNeg1_Button = new System.Windows.Forms.Button();
            this.xSquared_Button = new System.Windows.Forms.Button();
            this.xCubed_Button = new System.Windows.Forms.Button();
            this.pi_Button = new System.Windows.Forms.Button();
            this.Button_7 = new System.Windows.Forms.Button();
            this.Button_8 = new System.Windows.Forms.Button();
            this.Button_9 = new System.Windows.Forms.Button();
            this.Button_4 = new System.Windows.Forms.Button();
            this.Button_5 = new System.Windows.Forms.Button();
            this.Button_6 = new System.Windows.Forms.Button();
            this.Button_1 = new System.Windows.Forms.Button();
            this.Button_2 = new System.Windows.Forms.Button();
            this.Button_3 = new System.Windows.Forms.Button();
            this.Button_0 = new System.Windows.Forms.Button();
            this.dot_Button = new System.Windows.Forms.Button();
            this.Equals_Button = new System.Windows.Forms.Button();
            this.Div_Button = new System.Windows.Forms.Button();
            this.Mult_Button = new System.Windows.Forms.Button();
            this.Sust_Button = new System.Windows.Forms.Button();
            this.Sum_Button = new System.Windows.Forms.Button();
            this.SqurRoot_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Principal
            // 
            this.Principal.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Principal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Principal.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Principal.Location = new System.Drawing.Point(12, 12);
            this.Principal.Multiline = true;
            this.Principal.Name = "Principal";
            this.Principal.Size = new System.Drawing.Size(514, 62);
            this.Principal.TabIndex = 0;
            this.Principal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // MC_Button
            // 
            this.MC_Button.BackColor = System.Drawing.SystemColors.ControlDark;
            this.MC_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MC_Button.Location = new System.Drawing.Point(12, 92);
            this.MC_Button.Name = "MC_Button";
            this.MC_Button.Size = new System.Drawing.Size(59, 30);
            this.MC_Button.TabIndex = 1;
            this.MC_Button.Text = "MC";
            this.MC_Button.UseVisualStyleBackColor = false;
            this.MC_Button.Click += new System.EventHandler(this.MC_Button_Click);
            // 
            // MR_Button
            // 
            this.MR_Button.BackColor = System.Drawing.SystemColors.ControlDark;
            this.MR_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MR_Button.Location = new System.Drawing.Point(77, 92);
            this.MR_Button.Name = "MR_Button";
            this.MR_Button.Size = new System.Drawing.Size(59, 30);
            this.MR_Button.TabIndex = 2;
            this.MR_Button.Text = "MR";
            this.MR_Button.UseVisualStyleBackColor = false;
            this.MR_Button.Click += new System.EventHandler(this.MR_Button_Click);
            // 
            // MS_Button
            // 
            this.MS_Button.BackColor = System.Drawing.SystemColors.ControlDark;
            this.MS_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MS_Button.Location = new System.Drawing.Point(142, 92);
            this.MS_Button.Name = "MS_Button";
            this.MS_Button.Size = new System.Drawing.Size(59, 30);
            this.MS_Button.TabIndex = 3;
            this.MS_Button.Text = "MS";
            this.MS_Button.UseVisualStyleBackColor = false;
            this.MS_Button.Click += new System.EventHandler(this.MS_Button_Click);
            // 
            // MPlus_Button
            // 
            this.MPlus_Button.BackColor = System.Drawing.SystemColors.ControlDark;
            this.MPlus_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MPlus_Button.Location = new System.Drawing.Point(207, 92);
            this.MPlus_Button.Name = "MPlus_Button";
            this.MPlus_Button.Size = new System.Drawing.Size(59, 30);
            this.MPlus_Button.TabIndex = 4;
            this.MPlus_Button.Text = "M+";
            this.MPlus_Button.UseVisualStyleBackColor = false;
            this.MPlus_Button.Click += new System.EventHandler(this.MPlus_Button_Click);
            // 
            // MSust_Button
            // 
            this.MSust_Button.BackColor = System.Drawing.SystemColors.ControlDark;
            this.MSust_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MSust_Button.Location = new System.Drawing.Point(272, 92);
            this.MSust_Button.Name = "MSust_Button";
            this.MSust_Button.Size = new System.Drawing.Size(59, 30);
            this.MSust_Button.TabIndex = 5;
            this.MSust_Button.Text = "M-";
            this.MSust_Button.UseVisualStyleBackColor = false;
            this.MSust_Button.Click += new System.EventHandler(this.MSust_Button_Click);
            // 
            // CE_Button
            // 
            this.CE_Button.BackColor = System.Drawing.Color.Orange;
            this.CE_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CE_Button.ForeColor = System.Drawing.Color.Black;
            this.CE_Button.Location = new System.Drawing.Point(337, 92);
            this.CE_Button.Name = "CE_Button";
            this.CE_Button.Size = new System.Drawing.Size(124, 30);
            this.CE_Button.TabIndex = 6;
            this.CE_Button.Text = "CE";
            this.CE_Button.UseVisualStyleBackColor = false;
            this.CE_Button.Click += new System.EventHandler(this.CE_Button_Click);
            // 
            // C_Button
            // 
            this.C_Button.BackColor = System.Drawing.Color.Orange;
            this.C_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.C_Button.Location = new System.Drawing.Point(467, 92);
            this.C_Button.Name = "C_Button";
            this.C_Button.Size = new System.Drawing.Size(59, 30);
            this.C_Button.TabIndex = 7;
            this.C_Button.Text = "DEL";
            this.C_Button.UseVisualStyleBackColor = false;
            this.C_Button.Click += new System.EventHandler(this.C_Button_Click);
            // 
            // sinh_Button
            // 
            this.sinh_Button.BackColor = System.Drawing.Color.Silver;
            this.sinh_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sinh_Button.Location = new System.Drawing.Point(12, 128);
            this.sinh_Button.Name = "sinh_Button";
            this.sinh_Button.Size = new System.Drawing.Size(59, 30);
            this.sinh_Button.TabIndex = 8;
            this.sinh_Button.Text = "sinh";
            this.sinh_Button.UseVisualStyleBackColor = false;
            this.sinh_Button.Click += new System.EventHandler(this.sinh_Button_Click);
            // 
            // cosh_Button
            // 
            this.cosh_Button.BackColor = System.Drawing.Color.Silver;
            this.cosh_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cosh_Button.Location = new System.Drawing.Point(12, 164);
            this.cosh_Button.Name = "cosh_Button";
            this.cosh_Button.Size = new System.Drawing.Size(59, 30);
            this.cosh_Button.TabIndex = 9;
            this.cosh_Button.Text = "cosh";
            this.cosh_Button.UseVisualStyleBackColor = false;
            this.cosh_Button.Click += new System.EventHandler(this.cosh_Button_Click);
            // 
            // tanh_Button
            // 
            this.tanh_Button.BackColor = System.Drawing.Color.Silver;
            this.tanh_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tanh_Button.Location = new System.Drawing.Point(12, 200);
            this.tanh_Button.Name = "tanh_Button";
            this.tanh_Button.Size = new System.Drawing.Size(59, 30);
            this.tanh_Button.TabIndex = 10;
            this.tanh_Button.Text = "tanh";
            this.tanh_Button.UseVisualStyleBackColor = false;
            this.tanh_Button.Click += new System.EventHandler(this.tanh_Button_Click);
            // 
            // Exp_Button
            // 
            this.Exp_Button.BackColor = System.Drawing.Color.Silver;
            this.Exp_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exp_Button.Location = new System.Drawing.Point(12, 236);
            this.Exp_Button.Name = "Exp_Button";
            this.Exp_Button.Size = new System.Drawing.Size(59, 30);
            this.Exp_Button.TabIndex = 11;
            this.Exp_Button.Text = "Exp";
            this.Exp_Button.UseVisualStyleBackColor = false;
            this.Exp_Button.Click += new System.EventHandler(this.Exp_Button_Click);
            // 
            // Factorial_Button
            // 
            this.Factorial_Button.BackColor = System.Drawing.Color.Silver;
            this.Factorial_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Factorial_Button.Location = new System.Drawing.Point(12, 272);
            this.Factorial_Button.Name = "Factorial_Button";
            this.Factorial_Button.Size = new System.Drawing.Size(59, 30);
            this.Factorial_Button.TabIndex = 12;
            this.Factorial_Button.Text = "x!";
            this.Factorial_Button.UseVisualStyleBackColor = false;
            this.Factorial_Button.Click += new System.EventHandler(this.Factorial_Button_Click);
            // 
            // Euler_Button
            // 
            this.Euler_Button.BackColor = System.Drawing.Color.Silver;
            this.Euler_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Euler_Button.Location = new System.Drawing.Point(77, 272);
            this.Euler_Button.Name = "Euler_Button";
            this.Euler_Button.Size = new System.Drawing.Size(59, 30);
            this.Euler_Button.TabIndex = 13;
            this.Euler_Button.Text = "e";
            this.Euler_Button.UseVisualStyleBackColor = false;
            this.Euler_Button.Click += new System.EventHandler(this.Euler_Button_Click);
            // 
            // Tentox_Button
            // 
            this.Tentox_Button.BackColor = System.Drawing.Color.Silver;
            this.Tentox_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Tentox_Button.Location = new System.Drawing.Point(142, 272);
            this.Tentox_Button.Name = "Tentox_Button";
            this.Tentox_Button.Size = new System.Drawing.Size(59, 30);
            this.Tentox_Button.TabIndex = 14;
            this.Tentox_Button.Text = "10x";
            this.Tentox_Button.UseVisualStyleBackColor = false;
            this.Tentox_Button.Click += new System.EventHandler(this.Tentox_Button_Click);
            // 
            // Percentage_Button
            // 
            this.Percentage_Button.BackColor = System.Drawing.Color.Silver;
            this.Percentage_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Percentage_Button.Location = new System.Drawing.Point(207, 272);
            this.Percentage_Button.Name = "Percentage_Button";
            this.Percentage_Button.Size = new System.Drawing.Size(59, 30);
            this.Percentage_Button.TabIndex = 15;
            this.Percentage_Button.Text = "%";
            this.Percentage_Button.UseVisualStyleBackColor = false;
            this.Percentage_Button.Click += new System.EventHandler(this.Percentage_Button_Click);
            // 
            // NegPos_Button
            // 
            this.NegPos_Button.BackColor = System.Drawing.Color.Silver;
            this.NegPos_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NegPos_Button.Location = new System.Drawing.Point(272, 272);
            this.NegPos_Button.Name = "NegPos_Button";
            this.NegPos_Button.Size = new System.Drawing.Size(59, 30);
            this.NegPos_Button.TabIndex = 16;
            this.NegPos_Button.Text = "-/+";
            this.NegPos_Button.UseVisualStyleBackColor = false;
            this.NegPos_Button.Click += new System.EventHandler(this.NegPos_Button_Click);
            // 
            // sec_Button
            // 
            /*
            this.sec_Button.BackColor = System.Drawing.Color.Silver;
            this.sec_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sec_Button.Location = new System.Drawing.Point(77, 128);
            this.sec_Button.Name = "sec_Button";
            this.sec_Button.Size = new System.Drawing.Size(59, 30);
            this.sec_Button.TabIndex = 17;
            this.sec_Button.Text = "sec";
            this.sec_Button.UseVisualStyleBackColor = false;
            this.sec_Button.Click += new System.EventHandler(this.sec_Button_Click);
            */
            // 
            // csc_Button
            // 
            this.csc_Button.BackColor = System.Drawing.Color.Silver;
            this.csc_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.csc_Button.Location = new System.Drawing.Point(77, 164);
            this.csc_Button.Name = "csc_Button";
            this.csc_Button.Size = new System.Drawing.Size(59, 30);
            this.csc_Button.TabIndex = 18;
            this.csc_Button.Text = "csc";
            this.csc_Button.UseVisualStyleBackColor = false;
            this.csc_Button.Click += new System.EventHandler(this.csc_Button_Click);
            // 
            // cot_Button
            // 
            this.cot_Button.BackColor = System.Drawing.Color.Silver;
            this.cot_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cot_Button.Location = new System.Drawing.Point(77, 200);
            this.cot_Button.Name = "cot_Button";
            this.cot_Button.Size = new System.Drawing.Size(59, 30);
            this.cot_Button.TabIndex = 19;
            this.cot_Button.Text = "cot";
            this.cot_Button.UseVisualStyleBackColor = false;
            this.cot_Button.Click += new System.EventHandler(this.cot_Button_Click);
            // 
            // log_Button
            // 
            this.log_Button.BackColor = System.Drawing.Color.Silver;
            this.log_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.log_Button.Location = new System.Drawing.Point(77, 236);
            this.log_Button.Name = "log_Button";
            this.log_Button.Size = new System.Drawing.Size(59, 30);
            this.log_Button.TabIndex = 20;
            this.log_Button.Text = "log";
            this.log_Button.UseVisualStyleBackColor = false;
            this.log_Button.Click += new System.EventHandler(this.log_Button_Click);
            // 
            // NatLog_Button
            // 
            this.NatLog_Button.BackColor = System.Drawing.Color.Silver;
            this.NatLog_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NatLog_Button.Location = new System.Drawing.Point(142, 236);
            this.NatLog_Button.Name = "NatLog_Button";
            this.NatLog_Button.Size = new System.Drawing.Size(59, 30);
            this.NatLog_Button.TabIndex = 21;
            this.NatLog_Button.Text = "ln";
            this.NatLog_Button.UseVisualStyleBackColor = false;
            this.NatLog_Button.Click += new System.EventHandler(this.NatLog_Button_Click);
            // 
            // tan_Button
            // 
            this.tan_Button.BackColor = System.Drawing.Color.Silver;
            this.tan_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tan_Button.Location = new System.Drawing.Point(142, 200);
            this.tan_Button.Name = "tan_Button";
            this.tan_Button.Size = new System.Drawing.Size(59, 30);
            this.tan_Button.TabIndex = 22;
            this.tan_Button.Text = "tan";
            this.tan_Button.UseVisualStyleBackColor = false;
            this.tan_Button.Click += new System.EventHandler(this.tan_Button_Click);
            // 
            // cos_Button
            // 
            this.cos_Button.BackColor = System.Drawing.Color.Silver;
            this.cos_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cos_Button.Location = new System.Drawing.Point(142, 164);
            this.cos_Button.Name = "cos_Button";
            this.cos_Button.Size = new System.Drawing.Size(59, 30);
            this.cos_Button.TabIndex = 23;
            this.cos_Button.Text = "cos";
            this.cos_Button.UseVisualStyleBackColor = false;
            this.cos_Button.Click += new System.EventHandler(this.cos_Button_Click);
            // 
            // sin_Button
            // 
            this.sin_Button.BackColor = System.Drawing.Color.Silver;
            this.sin_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sin_Button.Location = new System.Drawing.Point(142, 128);
            this.sin_Button.Name = "sin_Button";
            this.sin_Button.Size = new System.Drawing.Size(59, 30);
            this.sin_Button.TabIndex = 24;
            this.sin_Button.Text = "sin";
            this.sin_Button.UseVisualStyleBackColor = false;
            this.sin_Button.Click += new System.EventHandler(this.sin_Button_Click);
            // 
            // xRaisedNeg1_Button
            // 
            this.xRaisedNeg1_Button.BackColor = System.Drawing.Color.Silver;
            this.xRaisedNeg1_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xRaisedNeg1_Button.Location = new System.Drawing.Point(207, 128);
            this.xRaisedNeg1_Button.Name = "xRaisedNeg1_Button";
            this.xRaisedNeg1_Button.Size = new System.Drawing.Size(59, 30);
            this.xRaisedNeg1_Button.TabIndex = 25;
            this.xRaisedNeg1_Button.Text = "x⁻¹";
            this.xRaisedNeg1_Button.UseVisualStyleBackColor = false;
            this.xRaisedNeg1_Button.Click += new System.EventHandler(this.xRaisedNeg1_Button_Click);
            // 
            // xSquared_Button
            // 
            this.xSquared_Button.BackColor = System.Drawing.Color.Silver;
            this.xSquared_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xSquared_Button.Location = new System.Drawing.Point(207, 164);
            this.xSquared_Button.Name = "xSquared_Button";
            this.xSquared_Button.Size = new System.Drawing.Size(59, 30);
            this.xSquared_Button.TabIndex = 26;
            this.xSquared_Button.Text = "x²";
            this.xSquared_Button.UseVisualStyleBackColor = false;
            this.xSquared_Button.Click += new System.EventHandler(this.xSquared_Button_Click);
            // 
            // xCubed_Button
            // 
            this.xCubed_Button.BackColor = System.Drawing.Color.Silver;
            this.xCubed_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xCubed_Button.Location = new System.Drawing.Point(207, 200);
            this.xCubed_Button.Name = "xCubed_Button";
            this.xCubed_Button.Size = new System.Drawing.Size(59, 30);
            this.xCubed_Button.TabIndex = 27;
            this.xCubed_Button.Text = "x³";
            this.xCubed_Button.UseVisualStyleBackColor = false;
            this.xCubed_Button.Click += new System.EventHandler(this.xCubed_Button_Click);
            // 
            // pi_Button
            // 
            this.pi_Button.BackColor = System.Drawing.Color.Silver;
            this.pi_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pi_Button.Location = new System.Drawing.Point(207, 236);
            this.pi_Button.Name = "pi_Button";
            this.pi_Button.Size = new System.Drawing.Size(59, 30);
            this.pi_Button.TabIndex = 28;
            this.pi_Button.Text = "π";
            this.pi_Button.UseVisualStyleBackColor = false;
            this.pi_Button.Click += new System.EventHandler(this.pi_Button_Click);
            // 
            // Button_7
            // 
            this.Button_7.BackColor = System.Drawing.Color.Black;
            this.Button_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_7.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_7.Location = new System.Drawing.Point(272, 128);
            this.Button_7.Name = "Button_7";
            this.Button_7.Size = new System.Drawing.Size(59, 30);
            this.Button_7.TabIndex = 29;
            this.Button_7.Text = "7";
            this.Button_7.UseVisualStyleBackColor = false;
            this.Button_7.Click += new System.EventHandler(this.Button_7_Click);
            // 
            // Button_8
            // 
            this.Button_8.BackColor = System.Drawing.Color.Black;
            this.Button_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_8.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_8.Location = new System.Drawing.Point(337, 128);
            this.Button_8.Name = "Button_8";
            this.Button_8.Size = new System.Drawing.Size(59, 30);
            this.Button_8.TabIndex = 30;
            this.Button_8.Text = "8";
            this.Button_8.UseVisualStyleBackColor = false;
            this.Button_8.Click += new System.EventHandler(this.Button_8_Click);
            // 
            // Button_9
            // 
            this.Button_9.BackColor = System.Drawing.Color.Black;
            this.Button_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_9.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_9.Location = new System.Drawing.Point(402, 128);
            this.Button_9.Name = "Button_9";
            this.Button_9.Size = new System.Drawing.Size(59, 30);
            this.Button_9.TabIndex = 31;
            this.Button_9.Text = "9";
            this.Button_9.UseVisualStyleBackColor = false;
            this.Button_9.Click += new System.EventHandler(this.Button_9_Click);
            // 
            // Button_4
            // 
            this.Button_4.BackColor = System.Drawing.Color.Black;
            this.Button_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_4.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_4.Location = new System.Drawing.Point(272, 164);
            this.Button_4.Name = "Button_4";
            this.Button_4.Size = new System.Drawing.Size(59, 30);
            this.Button_4.TabIndex = 32;
            this.Button_4.Text = "4";
            this.Button_4.UseVisualStyleBackColor = false;
            this.Button_4.Click += new System.EventHandler(this.Button_4_Click);
            // 
            // Button_5
            // 
            this.Button_5.BackColor = System.Drawing.Color.Black;
            this.Button_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_5.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_5.Location = new System.Drawing.Point(337, 164);
            this.Button_5.Name = "Button_5";
            this.Button_5.Size = new System.Drawing.Size(59, 30);
            this.Button_5.TabIndex = 33;
            this.Button_5.Text = "5";
            this.Button_5.UseVisualStyleBackColor = false;
            this.Button_5.Click += new System.EventHandler(this.Button_5_Click);
            // 
            // Button_6
            // 
            this.Button_6.BackColor = System.Drawing.Color.Black;
            this.Button_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_6.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_6.Location = new System.Drawing.Point(402, 164);
            this.Button_6.Name = "Button_6";
            this.Button_6.Size = new System.Drawing.Size(59, 30);
            this.Button_6.TabIndex = 34;
            this.Button_6.Text = "6";
            this.Button_6.UseVisualStyleBackColor = false;
            this.Button_6.Click += new System.EventHandler(this.Button_6_Click);
            // 
            // Button_1
            // 
            this.Button_1.BackColor = System.Drawing.Color.Black;
            this.Button_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_1.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_1.Location = new System.Drawing.Point(272, 200);
            this.Button_1.Name = "Button_1";
            this.Button_1.Size = new System.Drawing.Size(59, 30);
            this.Button_1.TabIndex = 35;
            this.Button_1.Text = "1";
            this.Button_1.UseVisualStyleBackColor = false;
            this.Button_1.Click += new System.EventHandler(this.Button_1_Click);
            // 
            // Button_2
            // 
            this.Button_2.BackColor = System.Drawing.Color.Black;
            this.Button_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_2.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_2.Location = new System.Drawing.Point(337, 200);
            this.Button_2.Name = "Button_2";
            this.Button_2.Size = new System.Drawing.Size(59, 30);
            this.Button_2.TabIndex = 36;
            this.Button_2.Text = "2";
            this.Button_2.UseVisualStyleBackColor = false;
            this.Button_2.Click += new System.EventHandler(this.Button_2_Click);
            // 
            // Button_3
            // 
            this.Button_3.BackColor = System.Drawing.Color.Black;
            this.Button_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_3.ForeColor = System.Drawing.SystemColors.Control;
            this.Button_3.Location = new System.Drawing.Point(402, 200);
            this.Button_3.Name = "Button_3";
            this.Button_3.Size = new System.Drawing.Size(59, 30);
            this.Button_3.TabIndex = 37;
            this.Button_3.Text = "3";
            this.Button_3.UseVisualStyleBackColor = false;
            this.Button_3.Click += new System.EventHandler(this.Button_3_Click);
            // 
            // Button_0
            // 
            this.Button_0.BackColor = System.Drawing.Color.Black;
            this.Button_0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button_0.ForeColor = System.Drawing.Color.White;
            this.Button_0.Location = new System.Drawing.Point(272, 236);
            this.Button_0.Name = "Button_0";
            this.Button_0.Size = new System.Drawing.Size(124, 30);
            this.Button_0.TabIndex = 38;
            this.Button_0.Text = "0";
            this.Button_0.UseVisualStyleBackColor = false;
            this.Button_0.Click += new System.EventHandler(this.Button_0_Click);
            // 
            // dot_Button
            // 
            this.dot_Button.BackColor = System.Drawing.Color.Silver;
            this.dot_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dot_Button.Location = new System.Drawing.Point(402, 236);
            this.dot_Button.Name = "dot_Button";
            this.dot_Button.Size = new System.Drawing.Size(59, 30);
            this.dot_Button.TabIndex = 39;
            this.dot_Button.Text = ".";
            this.dot_Button.UseVisualStyleBackColor = false;
            this.dot_Button.Click += new System.EventHandler(this.dot_Button_Click);
            // 
            // Equals_Button
            // 
            this.Equals_Button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Equals_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Equals_Button.Location = new System.Drawing.Point(337, 272);
            this.Equals_Button.Name = "Equals_Button";
            this.Equals_Button.Size = new System.Drawing.Size(124, 30);
            this.Equals_Button.TabIndex = 40;
            this.Equals_Button.Text = "=";
            this.Equals_Button.UseVisualStyleBackColor = false;
            this.Equals_Button.Click += new System.EventHandler(this.Equals_Button_Click);
            // 
            // Div_Button
            // 
            this.Div_Button.BackColor = System.Drawing.Color.Silver;
            this.Div_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Div_Button.Location = new System.Drawing.Point(467, 128);
            this.Div_Button.Name = "Div_Button";
            this.Div_Button.Size = new System.Drawing.Size(59, 30);
            this.Div_Button.TabIndex = 41;
            this.Div_Button.Text = "÷";
            this.Div_Button.UseVisualStyleBackColor = false;
            this.Div_Button.Click += new System.EventHandler(this.Div_Button_Click);
            // 
            // Mult_Button
            // 
            this.Mult_Button.BackColor = System.Drawing.Color.Silver;
            this.Mult_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Mult_Button.Location = new System.Drawing.Point(467, 164);
            this.Mult_Button.Name = "Mult_Button";
            this.Mult_Button.Size = new System.Drawing.Size(59, 30);
            this.Mult_Button.TabIndex = 42;
            this.Mult_Button.Text = "x";
            this.Mult_Button.UseVisualStyleBackColor = false;
            this.Mult_Button.Click += new System.EventHandler(this.Mult_Button_Click);
            // 
            // Sust_Button
            // 
            this.Sust_Button.BackColor = System.Drawing.Color.Silver;
            this.Sust_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sust_Button.Location = new System.Drawing.Point(467, 200);
            this.Sust_Button.Name = "Sust_Button";
            this.Sust_Button.Size = new System.Drawing.Size(59, 30);
            this.Sust_Button.TabIndex = 43;
            this.Sust_Button.Text = "-";
            this.Sust_Button.UseVisualStyleBackColor = false;
            this.Sust_Button.Click += new System.EventHandler(this.Sust_Button_Click);
            // 
            // Sum_Button
            // 
            this.Sum_Button.BackColor = System.Drawing.Color.Silver;
            this.Sum_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sum_Button.Location = new System.Drawing.Point(467, 236);
            this.Sum_Button.Name = "Sum_Button";
            this.Sum_Button.Size = new System.Drawing.Size(59, 30);
            this.Sum_Button.TabIndex = 44;
            this.Sum_Button.Text = "+";
            this.Sum_Button.UseVisualStyleBackColor = false;
            this.Sum_Button.Click += new System.EventHandler(this.Sum_Button_Click);
            // 
            // SqurRoot_Button
            // 
            this.SqurRoot_Button.BackColor = System.Drawing.Color.Silver;
            this.SqurRoot_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SqurRoot_Button.Location = new System.Drawing.Point(467, 272);
            this.SqurRoot_Button.Name = "SqurRoot_Button";
            this.SqurRoot_Button.Size = new System.Drawing.Size(59, 30);
            this.SqurRoot_Button.TabIndex = 45;
            this.SqurRoot_Button.Text = "√";
            this.SqurRoot_Button.UseVisualStyleBackColor = false;
            this.SqurRoot_Button.Click += new System.EventHandler(this.SqurRoot_Button_Click);
            // 
            // Scientific_Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(544, 313);
            this.Controls.Add(this.SqurRoot_Button);
            this.Controls.Add(this.Sum_Button);
            this.Controls.Add(this.Sust_Button);
            this.Controls.Add(this.Mult_Button);
            this.Controls.Add(this.Div_Button);
            this.Controls.Add(this.Equals_Button);
            this.Controls.Add(this.dot_Button);
            this.Controls.Add(this.Button_0);
            this.Controls.Add(this.Button_3);
            this.Controls.Add(this.Button_2);
            this.Controls.Add(this.Button_1);
            this.Controls.Add(this.Button_6);
            this.Controls.Add(this.Button_5);
            this.Controls.Add(this.Button_4);
            this.Controls.Add(this.Button_9);
            this.Controls.Add(this.Button_8);
            this.Controls.Add(this.Button_7);
            this.Controls.Add(this.pi_Button);
            this.Controls.Add(this.xCubed_Button);
            this.Controls.Add(this.xSquared_Button);
            this.Controls.Add(this.xRaisedNeg1_Button);
            this.Controls.Add(this.sin_Button);
            this.Controls.Add(this.cos_Button);
            this.Controls.Add(this.tan_Button);
            this.Controls.Add(this.NatLog_Button);
            this.Controls.Add(this.log_Button);
            this.Controls.Add(this.cot_Button);
            this.Controls.Add(this.csc_Button);
         //   this.Controls.Add(this.sec_Button);
            this.Controls.Add(this.NegPos_Button);
            this.Controls.Add(this.Percentage_Button);
            this.Controls.Add(this.Tentox_Button);
            this.Controls.Add(this.Euler_Button);
            this.Controls.Add(this.Factorial_Button);
            this.Controls.Add(this.Exp_Button);
            this.Controls.Add(this.tanh_Button);
            this.Controls.Add(this.cosh_Button);
            this.Controls.Add(this.sinh_Button);
            this.Controls.Add(this.C_Button);
            this.Controls.Add(this.CE_Button);
            this.Controls.Add(this.MSust_Button);
            this.Controls.Add(this.MPlus_Button);
            this.Controls.Add(this.MS_Button);
            this.Controls.Add(this.MR_Button);
            this.Controls.Add(this.MC_Button);
            this.Controls.Add(this.Principal);
            this.Name = "Scientific_Calculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Scientific Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Principal;
        private System.Windows.Forms.Button MC_Button;
        private System.Windows.Forms.Button MR_Button;
        private System.Windows.Forms.Button MS_Button;
        private System.Windows.Forms.Button MPlus_Button;
        private System.Windows.Forms.Button MSust_Button;
        private System.Windows.Forms.Button CE_Button;
        private System.Windows.Forms.Button C_Button;
        private System.Windows.Forms.Button sinh_Button;
        private System.Windows.Forms.Button cosh_Button;
        private System.Windows.Forms.Button tanh_Button;
        private System.Windows.Forms.Button Exp_Button;
        private System.Windows.Forms.Button Factorial_Button;
        private System.Windows.Forms.Button Euler_Button;
        private System.Windows.Forms.Button Tentox_Button;
        private System.Windows.Forms.Button Percentage_Button;
        private System.Windows.Forms.Button NegPos_Button;
// private System.Windows.Forms.Button sec_Button;
        private System.Windows.Forms.Button csc_Button;
        private System.Windows.Forms.Button cot_Button;
        private System.Windows.Forms.Button log_Button;
        private System.Windows.Forms.Button NatLog_Button;
        private System.Windows.Forms.Button tan_Button;
        private System.Windows.Forms.Button cos_Button;
        private System.Windows.Forms.Button sin_Button;
        private System.Windows.Forms.Button xRaisedNeg1_Button;
        private System.Windows.Forms.Button xSquared_Button;
        private System.Windows.Forms.Button xCubed_Button;
        private System.Windows.Forms.Button pi_Button;
        private System.Windows.Forms.Button Button_7;
        private System.Windows.Forms.Button Button_8;
        private System.Windows.Forms.Button Button_9;
        private System.Windows.Forms.Button Button_4;
        private System.Windows.Forms.Button Button_5;
        private System.Windows.Forms.Button Button_6;
        private System.Windows.Forms.Button Button_1;
        private System.Windows.Forms.Button Button_2;
        private System.Windows.Forms.Button Button_3;
        private System.Windows.Forms.Button Button_0;
        private System.Windows.Forms.Button dot_Button;
        private System.Windows.Forms.Button Equals_Button;
        private System.Windows.Forms.Button Div_Button;
        private System.Windows.Forms.Button Mult_Button;
        private System.Windows.Forms.Button Sust_Button;
        private System.Windows.Forms.Button Sum_Button;
        private System.Windows.Forms.Button SqurRoot_Button;
    }
}

